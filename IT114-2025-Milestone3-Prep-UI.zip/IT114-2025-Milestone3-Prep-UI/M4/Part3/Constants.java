package M4.Part3;

public abstract class Constants {
    final public static String COMMAND_TRIGGER = "[cmd]";
}
