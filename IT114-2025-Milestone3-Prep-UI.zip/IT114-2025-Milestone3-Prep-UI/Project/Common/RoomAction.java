package Project.Common;

public enum RoomAction {
    CREATE, JOIN, LEAVE, LIST
}
