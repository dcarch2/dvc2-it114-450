package Project.Common;

public enum TimerType {
    READY, ROUND, TURN
}