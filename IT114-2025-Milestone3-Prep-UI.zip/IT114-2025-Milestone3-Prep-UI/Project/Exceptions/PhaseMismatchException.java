package Project.Exceptions;

public class PhaseMismatchException extends CustomIT114Exception {
    public PhaseMismatchException(String message) {
        super(message);
    }

    public PhaseMismatchException(String message, Throwable cause) {
        super(message, cause);
    }

}
