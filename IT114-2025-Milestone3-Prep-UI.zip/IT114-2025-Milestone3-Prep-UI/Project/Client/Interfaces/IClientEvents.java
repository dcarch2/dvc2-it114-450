package Project.Client.Interfaces;

/**
 * Base-class for events
 */
public interface IClientEvents {

}