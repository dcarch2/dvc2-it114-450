package Project.Client.Interfaces;

/**
 * Base-class for game specific events (used for organizing)
 */
public interface IGameEvents extends IClientEvents {
    
}