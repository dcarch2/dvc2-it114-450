package Project.Client;

public enum CardView {
    CONNECT, USER_INFO, CHAT, ROOMS,CHAT_GAME_SCREEN, GAME_SCREEN
}