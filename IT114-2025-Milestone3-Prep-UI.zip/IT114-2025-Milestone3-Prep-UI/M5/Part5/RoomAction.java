package M5.Part5;

public enum RoomAction {
    CREATE, JOIN, LEAVE
}
