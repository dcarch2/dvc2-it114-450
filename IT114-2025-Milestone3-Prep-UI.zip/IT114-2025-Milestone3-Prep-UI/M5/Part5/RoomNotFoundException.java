package M5.Part5;

public class RoomNotFoundException extends CustomIT114Exception {

    public RoomNotFoundException(String message) {
        super(message);
    }

    public RoomNotFoundException(String message, Throwable cause) {
        super(message, cause);
    }

}
