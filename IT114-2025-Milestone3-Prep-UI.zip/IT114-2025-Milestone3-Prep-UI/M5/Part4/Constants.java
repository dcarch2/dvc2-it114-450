package M5.Part4;

public abstract class Constants {
    final public static String COMMAND_TRIGGER = "[cmd]";
    final public static String SINGLE_SPACE = " ";
}
