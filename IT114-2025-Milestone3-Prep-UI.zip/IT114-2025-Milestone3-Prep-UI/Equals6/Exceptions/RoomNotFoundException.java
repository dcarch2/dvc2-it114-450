package Equals6.Exceptions;

public class RoomNotFoundException extends CustomIT114Exception {

    public RoomNotFoundException(String message) {
        super(message);
    }

    public RoomNotFoundException(String message, Throwable cause) {
        super(message, cause);
    }

}
