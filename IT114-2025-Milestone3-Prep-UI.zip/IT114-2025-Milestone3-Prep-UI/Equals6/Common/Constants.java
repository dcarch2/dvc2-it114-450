package Equals6.Common;

public abstract class Constants {
    final public static String COMMAND_TRIGGER = "/";
    final public static String SINGLE_SPACE = " ";
    final public static long DEFAULT_CLIENT_ID = -1;
}
