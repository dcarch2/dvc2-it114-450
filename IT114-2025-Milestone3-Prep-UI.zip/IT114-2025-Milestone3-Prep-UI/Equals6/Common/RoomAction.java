package Equals6.Common;

public enum RoomAction {
    CREATE, JOIN, LEAVE, LIST
}
