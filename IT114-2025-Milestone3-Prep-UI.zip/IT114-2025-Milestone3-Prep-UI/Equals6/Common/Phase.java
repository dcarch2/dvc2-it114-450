package Equals6.Common;

public enum Phase {
    READY, // pre-setup phase
    IN_PROGRESS, // example phase that'll be renamed/removed later
}